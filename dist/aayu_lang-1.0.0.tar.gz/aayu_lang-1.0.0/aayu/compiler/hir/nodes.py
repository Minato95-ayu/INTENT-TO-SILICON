from dataclasses import dataclass
from typing import List, Optional, Any

@dataclass(frozen=True, kw_only=True)
class HIRNode:
    """Base class for all High-Level Intermediate Representation nodes."""
    from aayu.compiler.errors import SourceSpan
    span: Optional[SourceSpan] = None

@dataclass(frozen=True, kw_only=True)
class HIRExpr(HIRNode):
    """Base for expressions that yield a value."""
    type_name: str = "any"

@dataclass(frozen=True, kw_only=True)
class HIRLocation(HIRExpr):
    """Represents a memory location (Local or Global)."""
    name: str

@dataclass(frozen=True, kw_only=True)
class HIRLocal(HIRLocation):
    """A local variable."""
    pass

@dataclass(frozen=True, kw_only=True)
class HIRGlobal(HIRLocation):
    """A global/state variable."""
    pass

@dataclass(frozen=True, kw_only=True)
class HIRConstant(HIRExpr):
    value: Any

@dataclass(frozen=True, kw_only=True)
class HIRBinaryOp(HIRExpr):
    operator: str
    left: HIRExpr
    right: HIRExpr

@dataclass(frozen=True, kw_only=True)
class HIRCall(HIRExpr):
    target: str
    args: List[HIRExpr]

@dataclass(frozen=True, kw_only=True)
class HIRAssign(HIRNode):
    target: HIRLocation
    value: HIRExpr

@dataclass(frozen=True, kw_only=True)
class HIRIf(HIRNode):
    condition: HIRExpr
    then_branch: List[HIRNode]
    else_branch: Optional[List[HIRNode]] = None

@dataclass(frozen=True, kw_only=True)
class HIRWhile(HIRNode):
    condition: HIRExpr
    body: List[HIRNode]

@dataclass(frozen=True, kw_only=True)
class HIRAction(HIRNode):
    name: str
    body: List[HIRNode]

@dataclass(frozen=True, kw_only=True)
class HIRReturn(HIRNode):
    value: Optional[HIRExpr] = None

@dataclass(frozen=True)
class HIRModule(HIRNode):
    globals: List[HIRAssign]  # State declarations map to global assignments
    actions: List[HIRAction]
