from aayu.compiler.hir.nodes import (
    HIRModule, HIRAction, HIRAssign, HIRIf, HIRWhile,
    HIRLocal, HIRGlobal, HIRConstant, HIRBinaryOp, HIRCall
)
from aayu.compiler.mir.nodes import (
    ModuleMIR, FunctionMIR, BasicBlock, Instruction, 
    Opcode, RegisterID, Metadata
)

class MIRBuilder:
    def __init__(self):
        self.register_count = 0
        self.block_count = 0
        self.current_function = None
        self.current_block = None

    def _next_reg(self) -> RegisterID:
        self.register_count += 1
        return RegisterID(self.register_count)

    def _new_block(self, prefix: str = "bb") -> BasicBlock:
        self.block_count += 1
        return BasicBlock(id=f"{prefix}_{self.block_count}")

    def build(self, hir: HIRModule) -> ModuleMIR:
        mod = ModuleMIR()
        for action in hir.actions:
            func = self._build_action(action)
            mod.functions.append(func)
        return mod

    def _build_action(self, action: HIRAction) -> FunctionMIR:
        self.register_count = 0
        self.block_count = 0
        
        self.current_function = FunctionMIR(name=action.name)
        entry = self._new_block("entry")
        self.current_function.blocks.append(entry)
        self.current_block = entry
        
        for stmt in action.body:
            self._build_stmt(stmt)
            
        return self.current_function

    def _build_stmt(self, stmt):
        if isinstance(stmt, HIRAssign):
            val_reg = self._build_expr(stmt.value)
            
            if isinstance(stmt.target, HIRLocal):
                instr = Instruction(opcode=Opcode.STORE_LOCAL, operands=[stmt.target.name, val_reg])
            else:
                instr = Instruction(opcode=Opcode.STORE_GLOBAL, operands=[stmt.target.name, val_reg])
            
            self.current_block.add_instruction(instr)

        elif isinstance(stmt, HIRCall):
            self._build_expr(stmt)

        elif type(stmt).__name__ == "HIRReturn":
            if stmt.value:
                val_reg = self._build_expr(stmt.value)
                self.current_block.add_instruction(Instruction(opcode=Opcode.RET, operands=[val_reg]))
            else:
                self.current_block.add_instruction(Instruction(opcode=Opcode.RET, operands=[]))

        elif isinstance(stmt, HIRIf):
            cond_reg = self._build_expr(stmt.condition)
            
            then_bb = self._new_block("then")
            else_bb = self._new_block("else")
            merge_bb = self._new_block("merge")
            
            # BRANCH to then or else
            branch_instr = Instruction(opcode=Opcode.BRANCH, operands=[cond_reg, then_bb.id, else_bb.id])
            self.current_block.add_instruction(branch_instr)
            
            # Link CFG
            self.current_block.successors.extend([then_bb, else_bb])
            then_bb.predecessors.append(self.current_block)
            else_bb.predecessors.append(self.current_block)
            
            self.current_function.blocks.append(then_bb)
            self.current_block = then_bb
            for t_stmt in stmt.then_branch:
                self._build_stmt(t_stmt)
            self.current_block.add_instruction(Instruction(opcode=Opcode.JUMP, operands=[merge_bb.id]))
            self.current_block.successors.append(merge_bb)
            merge_bb.predecessors.append(self.current_block)
            
            self.current_function.blocks.append(else_bb)
            self.current_block = else_bb
            if stmt.else_branch:
                for e_stmt in stmt.else_branch:
                    self._build_stmt(e_stmt)
            self.current_block.add_instruction(Instruction(opcode=Opcode.JUMP, operands=[merge_bb.id]))
            self.current_block.successors.append(merge_bb)
            merge_bb.predecessors.append(self.current_block)
            
            self.current_function.blocks.append(merge_bb)
            self.current_block = merge_bb

    def _build_expr(self, expr) -> RegisterID:
        dest = self._next_reg()
        
        if isinstance(expr, HIRConstant):
            instr = Instruction(opcode=Opcode.LOAD_CONST, operands=[expr.value], dest=dest)
            self.current_block.add_instruction(instr)
            
        elif isinstance(expr, HIRLocal):
            instr = Instruction(opcode=Opcode.LOAD_LOCAL, operands=[expr.name], dest=dest)
            self.current_block.add_instruction(instr)
            
        elif isinstance(expr, HIRGlobal):
            instr = Instruction(opcode=Opcode.LOAD_GLOBAL, operands=[expr.name], dest=dest)
            self.current_block.add_instruction(instr)
            
        elif isinstance(expr, HIRBinaryOp):
            left_reg = self._build_expr(expr.left)
            right_reg = self._build_expr(expr.right)
            
            op_map = {
                '+': Opcode.ADD, '-': Opcode.SUB, '*': Opcode.MUL, '/': Opcode.DIV,
                '==': Opcode.CMP_EQ, '>': Opcode.CMP_GT, '<': Opcode.CMP_LT
            }
            opc = op_map.get(expr.operator, Opcode.ADD)
            instr = Instruction(opcode=opc, operands=[left_reg, right_reg], dest=dest)
            self.current_block.add_instruction(instr)
            
        elif isinstance(expr, HIRCall):
            arg_regs = [self._build_expr(arg) for arg in expr.args]
            # Emit LOAD_GLOBAL for function target
            func_reg = self._next_reg()
            self.current_block.add_instruction(Instruction(opcode=Opcode.LOAD_GLOBAL, operands=[expr.target], dest=func_reg))
            # Emit CALL
            call_operands = [func_reg] + arg_regs
            self.current_block.add_instruction(Instruction(opcode=Opcode.CALL, operands=call_operands, dest=dest))
            
        return dest
