/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * AAYU Fullscreen Terminal
 * Opens upon pressing Run with stdout/stderr, interactive stdin, and return to editor navigation.
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowLeft,
  Trash2,
  Copy,
  Check,
  Send,
  Terminal as TerminalIcon,
  Cpu,
  Clock,
  Sparkles,
  AlertTriangle,
} from 'lucide-react';
import { ExecutionResult } from '../engine/types';

interface AayuTerminalProps {
  isOpen: boolean;
  onClose: () => void;
  fileName: string;
  result: ExecutionResult | null;
  isRunning: boolean;
  onSendStdin?: (input: string) => void;
}

export const AayuTerminal: React.FC<AayuTerminalProps> = ({
  isOpen,
  onClose,
  fileName,
  result,
  isRunning,
  onSendStdin,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [inputVal, setInputVal] = useState<string>('');
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, result, isRunning]);

  if (!isOpen) return null;

  const handleCopy = () => {
    const text = (result?.stdout || '') + (result?.stderr || '');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    if (onSendStdin) {
      onSendStdin(inputVal);
    }
    setInputVal('');
  };

  return (
    <div className="fixed inset-0 z-40 bg-black text-slate-100 flex flex-col font-mono select-text animate-in fade-in duration-150">
      {/* Top App Bar */}
      <div className="h-14 bg-[#121316] border-b border-[#232429] px-3 flex items-center justify-between shrink-0 select-none">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-200 transition-colors"
            title="Return to Editor"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>Terminal</span>
              <span className="text-[11px] font-normal text-emerald-400">[{fileName}]</span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              AAYU Stack Virtual Machine (ARM64)
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 select-none">
          <button
            onClick={handleCopy}
            className="p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
            title="Copy Output"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-[#232429] hover:bg-[#2e3037] text-xs font-semibold text-slate-200 transition-colors"
          >
            Exit
          </button>
        </div>
      </div>

      {/* Terminal Screen Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 leading-relaxed text-xs sm:text-sm">
        {/* Banner */}
        <div className="text-slate-500 text-[11px] pb-2 border-b border-slate-900 select-none">
          $ aayu run {fileName} --mode=arm64-native
        </div>

        {isRunning && (
          <div className="flex items-center gap-2 text-emerald-400 py-4 animate-pulse select-none">
            <Cpu className="w-4 h-4 animate-spin" />
            <span>Compiling AST & executing on Stack VM...</span>
          </div>
        )}

        {/* Stdout */}
        {result?.stdout && (
          <pre className="text-slate-100 whitespace-pre-wrap font-mono leading-relaxed">
            {result.stdout}
          </pre>
        )}

        {/* Stderr / Compiler Error */}
        {result?.stderr && (
          <div className="p-3 rounded bg-red-950/40 border border-red-900/60 text-red-300 whitespace-pre-wrap leading-relaxed font-mono flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div>{result.stderr}</div>
          </div>
        )}

        {/* Finished status ribbon */}
        {!isRunning && result && (
          <div className="pt-4 border-t border-slate-900 select-none space-y-1 text-[11px] text-slate-400">
            <div
              className={`font-bold ${
                result.success ? 'text-emerald-400' : 'text-red-400'
              }`}
            >
              [Program finished with exit code {result.exitCode}]
            </div>
            <div className="flex flex-wrap items-center gap-3 text-slate-500">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-cyan-400" />
                <span>{result.durationMs}ms</span>
              </span>
              <span className="flex items-center gap-1">
                <Cpu className="w-3 h-3 text-purple-400" />
                <span>{result.stepCount.toLocaleString()} steps</span>
              </span>
              <span className="flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" />
                <span>GC active: {result.gcStats.activeHeapObjects} objects</span>
              </span>
            </div>
            <div className="text-slate-600 pt-2">
              Press Enter or tap &apos;&larr;&apos; back arrow to return to editor
            </div>
          </div>
        )}

        <div ref={terminalEndRef} />
      </div>

      {/* Interactive Stdin input prompt at bottom */}
      <form
        onSubmit={handleSend}
        className="h-12 bg-[#121316] border-t border-[#232429] px-3 flex items-center gap-2 select-none"
      >
        <span className="text-emerald-400 font-mono text-sm">&gt;</span>
        <input
          type="text"
          placeholder="Send input to running program..."
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          className="flex-1 bg-transparent text-slate-100 placeholder-slate-600 outline-none text-xs sm:text-sm font-mono"
        />
        <button
          type="submit"
          className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
          title="Send Input"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
};
