/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Verified AAYU Example Programs and Starter Projects
 */

export interface ExampleProgram {
  id: string;
  title: string;
  category: 'Basics' | 'Algorithms' | 'Intent Database' | 'Intent Web & UI' | 'Native AI' | 'Multi-File';
  description: string;
  filename: string;
  code: string;
  virtualFiles?: Record<string, string>;
  expectedSnippet: string;
}

export const STARTER_EXAMPLES: ExampleProgram[] = [
  {
    id: 'ex-01-hello',
    title: 'Hello World',
    category: 'Basics',
    description: 'Classic first program printing strings and variables in AAYU.',
    filename: 'hello_world.aayu',
    code: `// Verified AAYU Example: Hello World
let app_name = "AAYU Mobile IDE"
let platform = "Android"

println("Welcome to " + app_name + " for " + platform + "!")
println("Intent to Silicon: Fast, Safe, Zero Dependencies.")
`,
    expectedSnippet: 'Welcome to AAYU Mobile IDE for Android!',
  },
  {
    id: 'ex-02-variables',
    title: 'Variables & Arithmetic',
    category: 'Basics',
    description: 'Integer/Float math operations, powers, remainders, and string concatenation.',
    filename: 'variables_math.aayu',
    code: `// Variables & Arithmetic Evaluation
let radius = 7.5
let pi = 3.14159

let circumference = 2 * pi * radius
let area = pi * (radius ^ 2)

println("Radius:", radius)
println("Circumference:", circumference)
println("Circle Area:", area)

// Increment assignment
let counter = 10
counter += 5
println("Counter after += 5:", counter)
`,
    expectedSnippet: 'Circle Area: 176.7144',
  },
  {
    id: 'ex-03-fibonacci',
    title: 'Fibonacci & Recursion',
    category: 'Algorithms',
    description: 'Recursive mathematical algorithms testing VM call-frames and stack allocation.',
    filename: 'fibonacci.aayu',
    code: `// Recursive Fibonacci Sequence Generator
fn fib(n) {
    if n <= 0 { return 0 }
    if n == 1 { return 1 }
    return fib(n - 1) + fib(n - 2)
}

println("Generating Fibonacci sequence:")
for i in range(0, 10) {
    println("fib(" + str(i) + ") =", fib(i))
}
`,
    expectedSnippet: 'fib(9) = 34',
  },
  {
    id: 'ex-04-bubble-sort',
    title: 'Bubble Sort Algorithm',
    category: 'Algorithms',
    description: 'In-place array manipulation, nested loops, and index assignment in AAYU.',
    filename: 'bubble_sort.aayu',
    code: `// Bubble Sort on AAYU Array
let items = [64, 34, 25, 12, 22, 11, 90]
let n = len(items)

println("Original array:", items)

for i in range(0, n) {
    for j in range(0, n - i - 1) {
        if items[j] > items[j + 1] {
            // Swap elements
            let temp = items[j]
            items[j] = items[j + 1]
            items[j + 1] = temp
        }
    }
}

println("Sorted array:", items)
`,
    expectedSnippet: 'Sorted array: [11,12,22,25,34,64,90]',
  },
  {
    id: 'ex-05-intent-database',
    title: 'Intent Relational Database (CRUD)',
    category: 'Intent Database',
    description: 'Native schema models, auto-increment IDs, inserts, and query filters without SQLite C dependencies.',
    filename: 'intent_database.aayu',
    code: `// AAYU Intent Relational Database
model Developer {
    id: int,
    name: str,
    experience_years: int,
    specialty: str
}

println("Inserting developer records...")
insert Developer {
    name: "Ayush Kaushik",
    experience_years: 6,
    specialty: "Compiler & Systems"
}

insert Developer {
    name: "Sophia Chen",
    experience_years: 4,
    specialty: "Android Jetpack Compose"
}

insert Developer {
    name: "Liam Patel",
    experience_years: 8,
    specialty: "Rust NDK Architecture"
}

println("\\nQuerying all developers:")
find Developer

println("\\nQuerying senior developers (experience >= 6):")
find Developer where experience_years >= 6
`,
    expectedSnippet: '[AAYU Intent DB] Initialized schema model',
  },
  {
    id: 'ex-06-intent-api',
    title: 'Intent REST API Routes',
    category: 'Intent Web & UI',
    description: 'Declarative REST route handling for microservices and mobile backends.',
    filename: 'intent_routes.aayu',
    code: `// AAYU Intent REST Service
model HealthCheck {
    status: str,
    uptime_sec: int
}

insert HealthCheck {
    status: "healthy",
    uptime_sec: 1420
}

route "GET /api/health" {
    find HealthCheck
}

route "POST /api/echo" {
    println("Echo endpoint hit!")
    return { "received": true, "timestamp": 1728860000 }
}

println("REST server configured. Switch to 'API & UI' tab to test routes.")
`,
    expectedSnippet: 'REST server configured',
  },
  {
    id: 'ex-07-intent-ui',
    title: 'Intent Declarative Mobile UI',
    category: 'Intent Web & UI',
    description: 'Declarative UI Tree that compiles to Android Compose or Web canvas widgets.',
    filename: 'declarative_ui.aayu',
    code: `// AAYU Declarative Mobile UI Tree
Page {
    Column [
        Text("AAYU Android Studio"),
        Text("Powered by Intent-to-Silicon"),
        Button("Compile & Run"),
        Button("Inspect Bytecode")
    ]
}

println("Declarative UI structure parsed successfully.")
`,
    expectedSnippet: 'Rendered declarative UI tree widget',
  },
  {
    id: 'ex-08-native-ai',
    title: 'Native AI: K-Means Clustering',
    category: 'Native AI',
    description: 'Zero-dependency machine learning clustering algorithm running directly in the Stack VM.',
    filename: 'kmeans_ai.aayu',
    code: `// Zero-Dependency Native AI: K-Means Clustering
let dataset = [
    [2.1, 1.8], [1.9, 2.2], [2.4, 2.0],
    [9.1, 8.9], [8.7, 9.2], [9.3, 8.6]
]

println("Running Native K-Means on " + str(len(dataset)) + " coordinates...")
let model = train_kmeans(dataset, 2)

println("Cluster 1 Centroid:", model["centroids"][0])
println("Cluster 2 Centroid:", model["centroids"][1])
println("Cluster assignments:", model["clusters"])
`,
    expectedSnippet: 'Running Native K-Means',
  },
  {
    id: 'ex-09-multi-file',
    title: 'Multi-File Module Import',
    category: 'Multi-File',
    description: 'Modular project with main.aayu importing helper functions from math_utils.aayu.',
    filename: 'main.aayu',
    virtualFiles: {
      'math_utils.aayu': `// math_utils.aayu - Mathematical Helper Library
fn square(x) { return x * x }
fn cube(x) { return x * x * x }
fn hypotenuse(a, b) {
    return ((a ^ 2) + (b ^ 2)) ^ 0.5
}
`,
    },
    code: `// Main Project File: imports helper module
import "math_utils.aayu"

let base = 6
let height = 8

println("Base:", base, "| Height:", height)
println("Base squared:", square(base))
println("Height squared:", square(height))
println("Hypotenuse:", hypotenuse(base, height))
`,
    expectedSnippet: 'Hypotenuse: 10',
  },
];
