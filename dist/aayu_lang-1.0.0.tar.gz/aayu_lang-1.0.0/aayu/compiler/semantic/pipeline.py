from typing import Optional
from aayu.compiler.ast.nodes import ProgramNode
from aayu.compiler.semantic.diagnostics import DiagnosticEngine, engine as global_diag_engine
from aayu.compiler.semantic.scope_pass import ScopePass
from aayu.compiler.semantic.symbol_pass import SymbolPass
from aayu.compiler.semantic.type_pass import TypePass
from aayu.compiler.semantic.constant_pass import ConstantPass
from aayu.compiler.hir.nodes import HIRModule
from aayu.compiler.hir.builder import HIRBuilder

class SemanticPipeline:
    """
    Phase 12.0 Semantic Pipeline Orchestrator
    Executes AST validation and transformation passes in strict order.
    Returns an immutable HIR (HIRModule) if successful.
    """
    def __init__(self, diag_engine: DiagnosticEngine = None):
        self.diag_engine = diag_engine or global_diag_engine
        
        # Expose passes so they can be run individually or accessed (e.g. for testing)
        self.scope_pass = None
        self.symbol_pass = None
        self.type_pass = None
        self.constant_pass = None

    def run(self, ast: ProgramNode) -> Optional[HIRModule]:
        self.diag_engine.clear()

        # 1. Scope Builder Pass
        self.scope_pass = ScopePass(self.diag_engine)
        self.scope_pass.run(ast)
        if self.diag_engine.has_errors():
            return None

        # 2. Symbol Resolver Pass
        self.symbol_pass = SymbolPass(self.diag_engine, self.scope_pass)
        self.symbol_pass.run(ast)
        if self.diag_engine.has_errors():
            return None

        # 3. Type Resolver Pass
        self.type_pass = TypePass(self.diag_engine, self.scope_pass)
        self.type_pass.run(ast)
        if self.diag_engine.has_errors():
            return None

        # 4. Constant Pass (returns new AST)
        self.constant_pass = ConstantPass(self.diag_engine, self.scope_pass)
        folded_ast = self.constant_pass.run(ast)
        if self.diag_engine.has_errors():
            return None

        # 5. HIR Generation
        builder = HIRBuilder(self.scope_pass)
        hir = builder.build(folded_ast)
        return hir
