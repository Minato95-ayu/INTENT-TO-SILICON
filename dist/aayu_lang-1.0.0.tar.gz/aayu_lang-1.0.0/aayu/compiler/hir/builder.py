from aayu.compiler.ast.nodes import (
    ProgramNode, StateDeclarationNode, LiteralNode,
    AssignmentNode, ActionDeclarationNode, ActionCallNode, IdentifierNode,
    IfNode, WhileNode, ForNode, BinaryOpNode,
    # WidgetNode, RouteNode, ReturnNode, ThemeNode, UseThemeNode, NavigateNode,
    # PropDeclarationNode, DictionaryNode, AwaitNode, BindNode, ValidateNode,
    # AnimateNode, LifecycleNode, ArrayNode, SubscriptNode,
    # TryNode, ThrowNode, RethrowNode
)
from aayu.compiler.semantic.symbols import SymbolTable
from aayu.compiler.hir.nodes import (
    HIRModule, HIRAction, HIRAssign, HIRIf, HIRWhile,
    HIRLocal, HIRGlobal, HIRConstant, HIRBinaryOp, HIRCall
)
from aayu.compiler.semantic.scope_pass import ScopePass

class HIRBuilder:
    """
    Phase 12.1 HIR Builder
    Translates a verified AST into an immutable, parser-independent High-Level IR.
    """
    def __init__(self, scope_pass: ScopePass):
        self.node_scopes = scope_pass.node_scopes
        self.node_types = getattr(scope_pass, 'node_types', {})
        self.global_scope = scope_pass.global_scope

    def build(self, ast: ProgramNode) -> HIRModule:
        globals_list = []
        actions = []
        
        for stmt in ast.statements:
            if isinstance(stmt, StateDeclarationNode):
                # State mapped to global assign
                val = self._build_expr(stmt.value, self.global_scope)
                globals_list.append(HIRAssign(target=HIRGlobal(name=stmt.name), value=val))
            elif isinstance(stmt, ActionDeclarationNode):
                actions.append(self._build_action(stmt))
                
        return HIRModule(globals=globals_list, actions=actions)

    def _build_action(self, node: ActionDeclarationNode) -> HIRAction:
        scope = self.node_scopes.get(id(node), self.global_scope)
        body = []
        for stmt in getattr(node, 'statements', []):
            built_stmt = self._build_stmt(stmt, scope)
            if built_stmt:
                body.append(built_stmt)
        return HIRAction(name=node.name, body=body)

    def _build_stmt(self, node, scope: SymbolTable):
        if isinstance(node, AssignmentNode):
            val = self._build_expr(node.value, scope)
            # Decide if target is local or global
            sym = scope.resolve(node.target)
            if sym and sym.symbol_type == 'state':
                target = HIRGlobal(name=node.target)
            else:
                target = HIRLocal(name=node.target)
            return HIRAssign(target=target, value=val)
            
        elif isinstance(node, IfNode):
            cond = self._build_expr(node.condition, scope)
            then_branch = [self._build_stmt(s, scope) for s in node.then_branch]
            then_branch = [s for s in then_branch if s is not None]
            
            else_branch = None
            if node.else_branch is not None:
                else_branch = [self._build_stmt(s, scope) for s in node.else_branch]
                else_branch = [s for s in else_branch if s is not None]
            return HIRIf(condition=cond, then_branch=then_branch, else_branch=else_branch)
            
        elif isinstance(node, WhileNode):
            loop_scope = self.node_scopes.get(id(node), scope)
            cond = self._build_expr(node.condition, loop_scope)
            body = [self._build_stmt(s, loop_scope) for s in node.body]
            body = [s for s in body if s is not None]
            return HIRWhile(condition=cond, body=body)
            
        elif isinstance(node, ActionCallNode):
            args = [self._build_expr(arg, scope) for arg in node.args]
            return HIRCall(target=node.name, args=args)
            
        elif isinstance(node, StateDeclarationNode):
            val = self._build_expr(node.value, scope)
            target = HIRLocal(name=node.name)
            return HIRAssign(target=target, value=val)
            
        elif type(node).__name__ == "ReturnNode":
            from aayu.compiler.hir.nodes import HIRReturn
            val = self._build_expr(node.value, scope) if node.value else None
            return HIRReturn(value=val)
            
        return None

    def _build_expr(self, node, scope: SymbolTable):
        t = self.node_types.get(id(node), "any")
        
        if isinstance(node, LiteralNode):
            return HIRConstant(value=node.value, type_name=t)
            
        elif isinstance(node, IdentifierNode):
            sym = scope.resolve(node.name)
            if sym and sym.symbol_type == 'state':
                return HIRGlobal(name=node.name, type_name=t)
            return HIRLocal(name=node.name, type_name=t)
            
        elif isinstance(node, BinaryOpNode):
            left = self._build_expr(node.left, scope)
            right = self._build_expr(node.right, scope)
            return HIRBinaryOp(operator=node.operator, left=left, right=right, type_name=t)
            
        elif isinstance(node, ActionCallNode):
            args = [self._build_expr(arg, scope) for arg in node.args]
            return HIRCall(target=node.name, args=args, type_name=t)
            
        # Fallback for complex expressions
        return HIRConstant(value=None, type_name="unknown")
