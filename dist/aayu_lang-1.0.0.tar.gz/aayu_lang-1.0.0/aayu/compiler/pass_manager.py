from abc import ABC, abstractmethod
from typing import Any, List, Type

class CompilerPass(ABC):
    @abstractmethod
    def run(self, node: Any) -> Any:
        pass
        
    def verify(self, node: Any) -> bool:
        return True
        
    def invalidate(self) -> None:
        pass

class AnalysisPass(CompilerPass):
    """Passes that do not mutate the AST/IR but gather information."""
    pass

class OptimizationPass(CompilerPass):
    """Passes that mutate the AST/IR to improve performance."""
    pass

class VerificationPass(CompilerPass):
    """Passes that verify the correctness of the IR."""
    pass

class LoweringPass(CompilerPass):
    """Passes that lower IR from one level to another (e.g. HIR -> MIR)."""
    pass

class AnalysisManager:
    """Manages cached analyses and invalidation for passes."""
    def __init__(self):
        self.cache: dict[Type[AnalysisPass], AnalysisPass] = {}
        
    def get_analysis(self, pass_type: Type[AnalysisPass], func: Any) -> AnalysisPass:
        if pass_type not in self.cache:
            p = pass_type()
            p.run(func)
            self.cache[pass_type] = p
        return self.cache[pass_type]
        
    def invalidate(self, pass_type: Type[AnalysisPass]):
        if pass_type in self.cache:
            del self.cache[pass_type]
            
    def invalidate_all(self):
        self.cache.clear()

class PassManager:
    """
    AAYU Generic Compiler Pass Manager
    Orchestrates the execution of different passes.
    """
    def __init__(self):
        self.passes: List[CompilerPass] = []
        self.analysis_manager = AnalysisManager()

    def add_pass(self, p: CompilerPass):
        self.passes.append(p)

    def run(self, module: Any) -> Any:
        current_node = module
        for p in self.passes:
            if hasattr(p, 'analysis_manager'):
                p.analysis_manager = self.analysis_manager
            current_node = p.run(current_node)
            if not p.verify(current_node):
                raise Exception(f"Pass {type(p).__name__} failed verification!")
        return current_node

    def invalidate_all(self):
        self.analysis_manager.invalidate_all()
        for p in self.passes:
            p.invalidate()
