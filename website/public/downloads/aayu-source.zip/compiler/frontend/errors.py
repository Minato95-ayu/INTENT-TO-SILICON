"""
=============================================================================
FILE: errors.py
PURPOSE: Part of the AAYU Intent-to-Silicon project
=============================================================================
This file is part of the AAYU (Aayu) Intent-to-Silicon Programming Language.
The AAYU language enables developers to write code using natural language
intentions, which are compiled to optimized backend code.

For beginners: This file handles part of the aayu intent-to-silicon project.
To understand the project architecture, see the ARCHITECTURE_FREEZE.md file.
=============================================================================
"""

import json

class AAYUError(Exception):
    def __init__(self, type_name, message, line, hint="", column=1):
        self.type_name = type_name
        self.message = message
        self.line = line
        self.column = column
        self.hint = hint
        super().__init__(self.message)

    def to_dict(self):
        return {
            "type": self.type_name,
            "line": self.line,
            "column": self.column,
            "message": self.message,
            "hint": self.hint
        }

    def format(self, use_color=True):
        if use_color:
            RED = '\033[91m'
            YELLOW = '\033[93m'
            BLUE = '\033[94m'
            RESET = '\033[0m'
        else:
            RED = YELLOW = BLUE = RESET = ''

        err_type = f"{RED}🔴 [AAYU {self.type_name}]{RESET}"
        line_info = f"{BLUE}Line {self.line}{RESET}"
        hint_info = f"\n{YELLOW}🟡 Hint:\n{self.hint}{RESET}" if self.hint else ""

        return f"\n{err_type}\n\n{line_info}\n{self.message}\n{hint_info}\n"

class AAYUSyntaxError(AAYUError):
    def __init__(self, message, line, hint="", column=1):
        super().__init__("Syntax Error", message, line, hint, column)

class AAYUTypeError(AAYUError):
    def __init__(self, code: str, message: str, line: int, hint: str = "", column: int = 1):
        super().__init__(f"TypeError {code}", message, line, hint, column)
        self.code = code

class AAYURuntimeError(AAYUError):
    def __init__(self, message, line, hint="", type_name="Runtime Error", column=1):
        super().__init__(type_name, message, line, hint, column)

class UndefinedVariableError(AAYURuntimeError):
    def __init__(self, message, line, hint=""):
        super().__init__(message, line, hint, type_name="Undefined Variable Error")

class DivisionByZeroError(AAYURuntimeError):
    def __init__(self, message, line, hint=""):
        super().__init__(message, line, hint, type_name="Division By Zero Error")

class IndexOutOfBoundsError(AAYURuntimeError):
    def __init__(self, message, line, hint=""):
        super().__init__(message, line, hint, type_name="Index Out Of Bounds Error")

class InvalidCallError(AAYURuntimeError):
    def __init__(self, message, line, hint=""):
        super().__init__(message, line, hint, type_name="Invalid Call Error")

class DatabaseError(AAYURuntimeError):
    def __init__(self, message, line, hint=""):
        super().__init__(message, line, hint, type_name="Database Error")

class AAYUDatabaseError(AAYUError):
    def __init__(self, message, line, hint=""):
        super().__init__("Database Error", message, line, hint)

class AAYUImportError(AAYUError):
    def __init__(self, message: str, line: int = 1, hint: str = ""):
        super().__init__("Import Error", message, line, hint)

class AAYUTestFailure(AAYUError):
    def __init__(self, message: str, line: int = 1, hint: str = ""):
        super().__init__("Test Failure", message, line, hint)
