fastapi>=0.103.1
uvicorn>=0.23.2
pydantic>=2.3.0
