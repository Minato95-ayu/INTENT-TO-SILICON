from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional

@dataclass
class SourceSpan:
    start_line: int
    start_col: int
    end_line: int
    end_col: int
    byte_offset: int = 0
    length: int = 0
    file: str = ""

    def __str__(self):
        return f"{self.file}:{self.start_line}:{self.start_col}"

class DiagnosticSeverity(Enum):
    INFO = auto()
    WARNING = auto()
    ERROR = auto()
    FATAL = auto()

@dataclass
class DiagnosticMessage:
    severity: DiagnosticSeverity
    message: str
    span: Optional[SourceSpan] = None
    hint: str = ""

    def format(self) -> str:
        prefix = self.severity.name
        loc = f" at {self.span}" if self.span else ""
        out = f"[{prefix}]{loc}: {self.message}"
        if self.hint:
            out += f"\n  Hint: {self.hint}"
        return out

class CompilerError(Exception):
    """
    A fatal compiler error that abruptly halts compilation if not caught.
    This should generally only be raised by the DiagnosticEngine on FATAL severity.
    """
    def __init__(self, message: str, line: int = 0, column: int = 0, source_line: str = "", hint: str = ""):
        self.message = message
        self.line = line
        self.column = column
        self.source_line = source_line
        self.hint = hint
        super().__init__(self.__str__())

    def __str__(self):
        if self.line == 0:
            msg = f"CompilerError: {self.message}"
            if self.hint:
                msg += f"\nHint: {self.hint}"
            return msg
            
        header = f"Error: {self.message}"
        if not self.source_line:
            if self.hint:
                header += f"\nHint: {self.hint}"
            return header
            
        # Format the error with a pointer caret
        pointer = " " * (max(0, self.column - 1)) + "^"
        output = f"\n{header}\n\n{self.line} | {self.source_line.rstrip()}\n  | {pointer}\n"
        if self.hint:
            output += f"\nHint:\n{self.hint}\n"
        return output

class DiagnosticEngine:
    """
    Centralized diagnostic reporter for the AAYU compiler.
    Eliminates bare asserts and raw exceptions during compilation.
    """
    def __init__(self):
        self.diagnostics: List[DiagnosticMessage] = []
    
    def has_errors(self) -> bool:
        return any(d.severity in (DiagnosticSeverity.ERROR, DiagnosticSeverity.FATAL) for d in self.diagnostics)
    
    def report(self, severity: DiagnosticSeverity, message: str, span: Optional[SourceSpan] = None, hint: str = ""):
        diag = DiagnosticMessage(severity, message, span, hint)
        self.diagnostics.append(diag)
        if severity == DiagnosticSeverity.FATAL:
            # FATAL severity halts execution immediately with a graceful CompilerError
            line = span.start_line if span else 0
            col = span.start_col if span else 0
            raise CompilerError(message, line, col, hint=hint)

    def print_all(self):
        for d in self.diagnostics:
            print(d.format())

    def clear(self):
        self.diagnostics.clear()